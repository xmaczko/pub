package pub;

public class Beer {
	public String name;
	public String style;
	public double strenght;
	public Beer() {	}
	public Beer(String n, String s, double t) {
		name = n;
		style = s;
		strenght = t;
	}
	
	public String getName() {return name;}
	public String getStyle() {return style;}
	public double getStrenght() {return strenght;}
	
	public String toString() {
		return getName() + " " + getStyle() + " " + getStrenght() + "%";
	}
	
	
}

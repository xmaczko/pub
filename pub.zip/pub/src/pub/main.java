package pub;
import java.util.Scanner;
import java.util.ArrayList;

public class main {
	protected static void addBeer(String[] datas, ArrayList<Beer> sorok) {
		String n = datas[1];
		String s = datas[2];
		double t = Double.valueOf(datas[3]);
		Beer new_beer = new Beer(n, s, t);
		sorok.add(new_beer);
	}
	protected static void list(ArrayList<Beer> sorok) {
		for(Beer x : sorok) {
			System.out.println(x.toString());
		}
	}
	
	private static Scanner input;
	
	public static void main(String[] args) {
		ArrayList<Beer> sorok = new ArrayList<Beer>();
		Beer soproni = new Beer("Soproni", "vil�gos", 4.5);
		sorok.add(soproni);
		Beer desperados = new Beer("Desperados", "tequil�s", 5);
		sorok.add(desperados);
		
		System.out.println(soproni.toString());
		System.out.println(desperados.toString());
		System.out.println();
		
		input = new Scanner(System.in);
		String sor;
		String[] darabok;
		while (true) {
			sor = input.nextLine();
			darabok = sor.split(" ");
			darabok[0] = darabok[0].toLowerCase();
			if (darabok[0].equals("exit")) { 
				break;
			}
			
			else if(darabok[0].equals("add")) {
				System.out.println(darabok[0] + " " + darabok.length);
				addBeer(darabok, sorok);				
			}
			
			else if(darabok[0].equals("list")) {
				list(sorok);
			}
			
		}
		System.out.println();
		
		
		System.out.println("Alkalmaz�s off");
	}

}
